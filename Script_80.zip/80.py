import pandas as pd
import shutil
import re
import os
from pathlib import Path
from datetime import datetime


filePath='C:/Debayan/Work/LnT Construction/Python/ExcelClean/tested'

Break=[]
for i in os.listdir(filePath):
    if str(i).lower()=='input':
        inPath=filePath+'/'+i+'/80/'
        for j in os.listdir(inPath):
            result= re.sub('[\W_]+', '', j)
            if 'mrnbreakupdetail' in result.lower() :
                Break.append(j)
            else:
                Break.append(j)
    elif str(i).lower()=='output':
        outputPath=filePath+'/'+i+'/80/'
    elif str(i).lower()=='archive':
        archivePath=filePath+'/'+i+'/80/'
print("No. of MRN Breakup files found:",Break)
print("started looping for each file")

for c in Break:
    print('---------------------------------------------------------------------------------')
    print('---------------------------------------------------------------------------------')
    print(f"Execution starts for file with name",c)
    folder=Path(inPath+c)
    print(f'reading file with name',c)
    df=pd.read_excel(folder)
    print('Excel file is read and is loaded into a DataFrame.....................!')
    print('Transformation began..................................................!')
    df.dropna(how='all',axis=1,inplace=True)
    df.dropna(how='all',axis=0,inplace=True)
    df.index=pd.RangeIndex(len(df))
    if pd.isnull(df.iloc[0,1]) :
        Date=df.iloc[0,2].split('PERIOD')[1]
    else:
        Date=df.iloc[0,1].split('PERIOD')[1]
    #Date=df.iloc[0,1].split('PERIOD')[1]
    vals=[]
    vals.append(datetime.strptime(Date.split('TO')[0].strip(),'%d/%b/%Y').strftime('%d/%m/%Y'))
    vals.append(datetime.strptime(Date.split('TO')[1].strip(),'%d/%b/%Y').strftime('%d/%m/%Y'))
    cols=['From','To']
    index=[]
    #print(df)
    for i in range(len(df)):
        #print(re.sub('[\W_]+', '',str(df.iloc[i,0])).lower())
        if re.sub('[\W_]+', '',str(df.iloc[i,0])).lower().startswith('client'):
            ind_df=i
    for i in range(len(df)):
        if re.sub('[\W_]+', '',str(df.iloc[i,0])).lower().startswith('transaction'):
            index.append(i)
    columns=df.iloc[ind_df].values.tolist()
    df_final=pd.DataFrame([],columns=columns)
    def transform(df,df_fin,ind):
        for i in range(len(ind)):
            if i!=len(ind)-1:
                df1=pd.DataFrame(df.iloc[ind[i]+1:ind[i+1],:])
                df1.columns=columns
                df1.insert(0,'TransactionType',[df.iloc[ind[i],1]]*len(df1))
                df_fin=df_fin.append(df1,sort=False,ignore_index=True)
            else:
                df1=pd.DataFrame(df.iloc[ind[i]+1:,:])
                df1.columns=columns
                df1.insert(0,'TransactionType',[df.iloc[ind[i],1]]*len(df1))
                df_fin=df_fin.append(df1,sort=False,ignore_index=True)
        return df_fin
    df_final=transform(df,df_final,index)
    for i in range(len(cols)):
        df_final.insert(i,cols[i],[vals[i]]*len(df_final))
    df_final.replace('.','',inplace=True)
    print('Transformation is successful..............!!!')
    print('Writing the data to Excel file.........!')
    df_final.to_excel(outputPath+'O_'+c,index=False)
    print('Please check output Excel file.........!')
    print('---------------------------------------------------------------')
    shutil.move(inPath+c,archivePath)
    print('Source file moved to archive path')
