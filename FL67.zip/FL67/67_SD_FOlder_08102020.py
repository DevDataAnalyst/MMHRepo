import pandas as pd
import re
from datetime import datetime
import os
from pathlib import Path
import shutil
mmh=[]
#filePath='C:/Users/gtl50user/Desktop/LnTProject'
filePath='D:/GTS_Project/From GTS/Scripts on 08072020/UpdatedBySD/Tested'

for i in os.listdir(filePath):
    if str(i).lower()=='input':
        inPath=filePath+'/'+i+"/67/"
        for j in os.listdir(inPath):
            result= re.sub('[\W_]+', '', j)
            if 'performancereport' in result.lower() :
                mmh.append(j)
            else:
                mmh.append(j)
    elif str(i).lower()=='output':
        outputPath=filePath+'/'+i+"/67/"
    elif str(i).lower()=='archive':
        archivePath=filePath+'/'+i+"/67/"
        
print("No. Invoice wise Summary:",mmh)
print("started looping for each file")
for c in mmh:
    print('---------------------------------------------------------------------------------')
    print('---------------------------------------------------------------------------------')    
    print(f"Execution starts for file with name",c)
    folder=Path(inPath+c)
    print(f'reading file with name',c)
    df=pd.read_excel(folder)
    print('Excel file is read and is loaded into a DataFrame.....................!')
    print('Transformation began..................................................!')
    df.dropna(how='all',axis=0,inplace=True)
    df.dropna(how='all',axis=1,inplace=True)
    df.index=pd.RangeIndex(len(df))
    for i in range(len(df)):
        if re.sub('[\W_]+', '',str(df.iloc[i,0])).lower()=='invoiceno':
            ind=i
            break
    df1=pd.DataFrame(df.iloc[ind:,:])
    df1.dropna(how='all',axis=0,inplace=True)
    df1.dropna(how='all',axis=1,inplace=True)
    df1.index=pd.RangeIndex(len(df1))
    ind1=0
    for i in range(len(df1)):
        if ' --------------------------------------------------------------------------' in str(df1.iloc[i,0]):
            df2=pd.DataFrame(df1.iloc[i+1:,:])
            ind1=i+1
            break
    df2.index=pd.RangeIndex(len(df2))
    columns=['Invoice No','InvoiceFrom','Cl.Reg','Certification Date','UptoPrevBill_Claims in Con.Curr','ThisBill_Claims in Con.Curr','UptoThisBill_Claims in Con.Curr',
          'InvoiceDate','Inv_To','Cert.Reg','UptoPrevBill_Claims in Nat.Curr','ThisBill_Claims in Nat.Curr','UptoThisBill_Claims in Nat.Curr',
          'UptoPrevBill_Recovery in Con.Curr','ThisBill_Recovery in Con.Curr','UptoThisBill_Recovery in Con.Curr','UptoPrevBill_Recovery in Nat.Curr','ThisBill_Recovery in Nat.Curr',
          'UptoThisBill_Recovery in Nat.Curr']
    def transform(df):
        ind=0
        row=0
        lst=[]
        for i in range(len(df)):
            if ' --------------------------------------------------------------------------' in str(df.iloc[i,0]):
                df1=pd.DataFrame(df.iloc[ind:i,:])
                ind=i+1
                lst1=[]
                df1.fillna('',inplace=True)
                for j in range(len(df1)):
                    for k in range(len(df1.columns)):
                        if str(df1.iloc[j,k])!='':
                            lst1.append(df1.iloc[j,k])
                lst.append(lst1)
        return lst
                            
    df_final=pd.DataFrame(transform(df2),columns=columns)
    cols=['Job','JobCode','JobDescription']
    vals=[df.iloc[1,0].split(',')[0],df.iloc[1,0].split(',')[0].split('-')[0],df.iloc[1,0].split(',')[0].split('-')[1]]
    val1=df.iloc[2].dropna(how='all',axis=0).values.tolist()
    val1[1]=datetime.strptime(val1[1].strip(),'%d/%b/%Y').strftime('%d/%m/%Y')
    val1[3]=datetime.strptime(val1[3].strip(),'%d/%b/%Y').strftime('%d/%m/%Y')
    val2=df.iloc[3].dropna(how='all',axis=0).values.tolist()
    val3=df.iloc[4].dropna(how='all',axis=0).values.tolist()
    cols.append(re.sub('[\W_]+', '',val1[0]))
    cols.append(re.sub('[\W_]+', '',val1[2]))
    cols.append(re.sub('[\W_]+', '',val2[0]))
    cols.append(re.sub('[\W_]+', '',val2[2]))
    cols.append(re.sub('[\W_]+', '',val3[0]))
    cols.append(re.sub('[\W_]+', '',val3[2]))
    vals.append(val1[1])
    vals.append(val1[3])
    vals.append(val2[1])
    vals.append(val2[3])
    vals.append(val3[1])
    vals.append(val3[3])
    for i in range(len(cols)):
        df_final.insert(i,cols[i],[vals[i]]*len(df_final))
    print('Transformation is successful..............!!!') 
    print('Writing the data to Excel file.........!')
    df_final.to_excel(outputPath+'O_'+c,index=False)
    print('Please check output Excel file.........!')
    print('---------------------------------------------------------------')
    shutil.move(inPath+c,archivePath)
    print('Source file moved to archive path')
    
