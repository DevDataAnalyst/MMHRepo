    #!/usr/bin/env python
# coding: utf-8

# In[143]:


import pandas as pd
import numpy as np
import re
from datetime import datetime
import os
from pathlib import Path
import shutil


# In[210]:



Surplus=[]
filePath='C:/Tested'
# filePath=os.getcwd()
for i in os.listdir(filePath):
    if str(i).lower()=='input':
        inPath=filePath+'/'+i+"/85/"
        for j in os.listdir(inPath):
            result= re.sub('[\W_]+', '', j)
            if 'MMH_IHC Loss Analysis' in result.lower() :
                Surplus.append(j)
            else:
                Surplus.append(j)
    elif str(i).lower()=='output':
        outputPath=filePath+'/'+i+"/85/"
    elif str(i).lower()=='archive':
        archivePath=filePath+'/'+i+"/85/"

print("No. Surplus Redployment:",Surplus)
print("started looping for each file")


# In[211]:



for c in Surplus:
    print('---------------------------------------------------------------------------------')
    print('---------------------------------------------------------------------------------')
    print(f"Execution starts for file with name",c)
    sheetName="18. BMH_BU wise Assets"
    folder=Path(inPath+c)
    print(f'reading file with name',c)
    df=pd.read_excel(folder)
    print('Excel file is read and is loaded into a DataFrame.....................!')
    print('Transformation began..................................................!')
    df.dropna(how='all',axis=1,inplace=True)
    df.dropna(how='all',axis=0,inplace=True)
    df.index=pd.RangeIndex(len(df))
    for i in range(len(df)):
        for j in range(len(df.columns)):
            if re.sub('[\W_]+', '',str(df.iloc[i,j])).lower()=='slno':
                ind_sl=i
                col_sl=j
            elif re.sub('[\W_]+', '',str(df.iloc[i,j])).lower()=='totalvalue':
                ind_total=i

    df1=pd.DataFrame(df.iloc[ind_sl:ind_total,col_sl:])
    df1.dropna(how='all',axis=0,inplace=True)
    df1.dropna(how='all',axis=1,inplace=True)
    df1.index=pd.RangeIndex(len(df1))
    lst1=df.iloc[ind_sl-3].dropna(how='all',axis=0).values.tolist()
    vals=[]
    vals.append(lst1[1].split('-')[0].strip())
    vals.append(lst1[1].split('-')[1].strip())  #cleanup needed
    columns=['JobID','JobDescription']
    columns.append(re.sub('[\W_]+', '',lst1[2]))
    vals.append(lst1[3].strip())
    lst2=df.iloc[ind_sl-2].dropna(how='all',axis=0).values.tolist()
    columns.append(re.sub('[\W_]+', '',lst2[0]))
    vals.append(lst2[1])
    columns.append(re.sub('[\W_]+', '',lst2[2]))
    columns.append(re.sub('[\W_]+', '',lst2[4]))
    vals.append(datetime.strptime(lst2[3],"%d - %b - %Y").strftime('%d/%m/%Y'))
    vals.append(datetime.strptime(lst2[5],"%d - %b - %Y").strftime('%d/%m/%Y'))
    lst3=df.iloc[ind_sl-1].dropna(how='all',axis=0).values.tolist()
    columns.append(re.sub('[\W_]+', '',lst3[0].split(':')[0]))
    vals.append(lst3[0].split(':')[1].strip())
    df1.columns=df1.iloc[0].values.tolist()
    df1.drop([0],axis=0,inplace=True)
    if len(df1)>0:
        for i in range(len(columns)-1):
            if columns[i] not in df1.columns:
                df1.insert(i,columns[i],[vals[i]]*len(df1))
            else:
                df1.insert(i,columns[i]+'Type',[vals[i]]*len(df1))
        df1.insert(len(df1.columns),columns[len(columns)-1],vals[len(vals)-1])
        df1.index=pd.RangeIndex(len(df1))
        for i in range(len(df1.columns)):
            if re.sub('[\W_]+', '',df1.columns[i]).lower()=='billamt':
                col1=i
                break
        for i in range(col1,len(df1.columns)):
            df1[df1.columns[i]]=df1[df1.columns[i]].astype(str)
            df1[df1.columns[i]]=df1[df1.columns[i]].astype(str)
            for j in range(len(df1[df1.columns[i]])):
                if '(' in df1.loc[j,df1.columns[i]]:
                    df1.loc[j,df1.columns[i]]=df1.loc[j,df1.columns[i]].replace('(','')
                    df1.loc[j,df1.columns[i]]=df1.loc[j,df1.columns[i]].replace(')','')
    else:
        df1.loc[0,df1.columns[1]]=vals[0]+'-'+vals[1]
        for i in range(len(columns)-1):
            if columns[i] not in df1.columns:
                df1.insert(i,columns[i],vals[i])
            else:
                df1.insert(i,columns[i]+'Type',[vals[i]])
        df1.insert(len(df1.columns),columns[len(columns)-1],vals[len(vals)-1])
    print('Transformation is successful..............!!!')
    print('Writing the data to Excel file.........!')
    df1.to_excel(outputPath+'O_'+c,index=False)




# In[ ]:
