#!/usr/bin/env python
# coding: utf-8

# In[1]:


import pandas as pd
import re
from datetime import datetime
import os
from pathlib import Path
import shutil


# In[76]:




Surplus=[]
filePath='D:/GTS_Project/From GTS/Scripts on 08072020/UpdatedBySD/Tested'
# filePath=os.getcwd()
for i in os.listdir(filePath):
    if str(i).lower()=='input':
        inPath=filePath+'/'+i+"/97/"
        for j in os.listdir(inPath):
            result= re.sub('[\W_]+', '', j)
            if 'MMH_IHC Loss Analysis' in result.lower() :
                Surplus.append(j)
            else:
                Surplus.append(j)
    elif str(i).lower()=='output':
        outputPath=filePath+'/'+i+"/97/"
    elif str(i).lower()=='archive':
        archivePath=filePath+'/'+i+"/97/"
        
print("No. Surplus Redployment:",Surplus)
print("started looping for each file")





# In[81]:




for c in Surplus:
    print('---------------------------------------------------------------------------------')
    print('---------------------------------------------------------------------------------')    
    print(f"Execution starts for file with name",c)
    folder=Path(inPath+c)
    print(f'reading file with name',c)
    df=pd.read_excel(folder,skiprows=8)
    df['Project Group'] = df.apply(lambda _: '', axis=1)
    print('Excel file is read and is loaded into a DataFrame.....................!')
    print('Transformation began..................................................!')
    #df = pd.read_excel(inputPath+filename)

    df.dropna(how='all',axis=0,inplace=True)
    df.dropna(how='all',axis=1,inplace=True)
   
    df.index=pd.RangeIndex(len(df))
    columns=df.columns.tolist()
    col_val=columns[0]
    for i in range(1,len(columns)):
        if 'none' not in columns[i].lower():
            col_val=columns[i]
        else:
            columns[i]=col_val
        
    val=df.iloc[0].fillna('').values.tolist()
    for i in range(len(columns)):
        if val[i]==' ':
            columns[i]=(columns[i]+val[i]).replace(' ','')
        else:
            columns[i]=(columns[i]+'_'+val[i]).replace(' ','')
            
    df.columns=columns
    df.drop([0],axis=0,inplace=True)
    print(df.columns)
    print('Transformation is successful..............!!!') 
    print('Writing the data to Excel file.........!')
    df.to_excel(outputPath+'O_'+c,index=False)


# In[ ]:




